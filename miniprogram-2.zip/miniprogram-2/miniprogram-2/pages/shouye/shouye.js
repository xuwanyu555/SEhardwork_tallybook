Page({
  data: {
    transactions: [],
    monthlyIncome: 0.00,
    monthlyExpense: 0.00,
    todayIncome: 0.00,
    todayExpense: 0.00,
    budgetText: "未设置预算",
    showBudgetDialog: false,
    budgetInput: ""
  },

  onLoad() {
    this.loadDataFromStorage();
  },

  loadDataFromStorage() {
    const zhichu = wx.getStorageSync('bills') || []; // 获取支出数据
    const shouru = wx.getStorageSync('shouru') || []; // 获取收入数据

    const today = new Date();
    const todayString = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;

    // 定义分类图标映射
    const categoryIcons = {
      '衣饰': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/yiblue.png',
      '住房': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/zublue.png',
      '餐饮': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/shiblue.png',
      '交通': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/xingblue.png',
      '衣物': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/yiblue.png',
      '工资': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/xinziora.png',
      '投资收益': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/touziora.png',
      '奖金': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/jiangjinora.png',
      '借入': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/jieruora.png',
      '其他': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/qitahui.png'
    };

    // 处理支出和收入数据
    const expenseTransactions = zhichu.map(item => ({
      ...item,
      type: '支出',
      icon: categoryIcons[item.category] || '/icons/default.png',
      amount: -Math.abs(item.amount), // 将支出标记为负数
      time: item.time || todayString // 如果没有时间，则设置为今天的日期
    }));

    const incomeTransactions = shouru.map(item => ({
      ...item,
      type: '收入',
      icon: categoryIcons[item.category] || '/icons/default.png',
      amount: Math.abs(item.amount),
      time: item.time || todayString
    }));

    const allTransactions = [...expenseTransactions, ...incomeTransactions];

    // 按时间从新到旧排序
    allTransactions.sort((a, b) => new Date(b.time) - new Date(a.time));

    // 更新页面数据
    this.setData({
      transactions: allTransactions
    });

    // 计算今天和本月的收入和支出
    const todayExpenses = expenseTransactions.filter(item => item.time === todayString).reduce((sum, item) => sum + Math.abs(item.amount), 0);
    const todayIncomes = incomeTransactions.filter(item => item.time === todayString).reduce((sum, item) => sum + item.amount, 0);

    const monthlyExpense = expenseTransactions.reduce((sum, item) => sum + Math.abs(item.amount), 0);
    const monthlyIncome = incomeTransactions.reduce((sum, item) => sum + item.amount, 0);

    this.setData({
      todayExpense: todayExpenses.toFixed(2),
      todayIncome: todayIncomes.toFixed(2),
      monthlyExpense: monthlyExpense.toFixed(2),
      monthlyIncome: monthlyIncome.toFixed(2)
    });
  },

  showBudgetInput() {
    this.setData({
      showBudgetDialog: true
    });
  },

  updateBudgetInput(e) {
    this.setData({
      budgetInput: e.detail.value
    });
  },

  onjiyibi() {
    wx.navigateTo({
      url: '/pages/jiyibi/jiyibi'
    });
  },

  setBudget() {
    const budget = this.data.budgetInput;
    this.setData({
      budgetText: budget ? `¥ ${budget}` : "未设置预算",
      showBudgetDialog: false
    });
  }
});
