Page({
  data: {
    items: [], // 用于存储动态加载的账单数据
    month: '' // 用于存储当前月份
  },

  onLoad() {
    this.loadBills();
    this.setCurrentMonth();
  },

  loadBills() {
    const bills = wx.getStorageSync('bills') || []; // 加载支出数据
    const shouru = wx.getStorageSync('shouru') || []; // 加载收入数据

    // 将支出和收入数据合并到一个数组中，并标记类型
    const items = bills.map(bill => ({
      icon: this.getIconForCategory(bill.category),
      category: bill.category,
      note: bill.note,
      amount: `¥ ${bill.amount}`,
      date: bill.date,
      type: '支出' // 标记为支出
    })).concat(shouru.map(income => ({
      icon: this.getIconForCategory(income.category),
      category: income.category,
      note: income.note,
      amount: `¥ ${income.amount}`,
      date: income.date,
      type: '收入' // 标记为收入
    })));

    // 按时间排序（假设 date 格式是 "YYYY年MM月DD日 HH:MM" 或 "今天 HH:MM"）
    items.sort((a, b) => {
      const dateA = new Date(this.formatDateToSortable(a.date));
      const dateB = new Date(this.formatDateToSortable(b.date));
      return dateB - dateA; // 从新到旧排序
    });

    this.setData({ items });
  },

  formatDateToSortable(dateStr) {
    // 将"今天"等替换为当前日期
    if (dateStr.includes('今天')) {
      const today = new Date();
      const formattedToday = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
      return dateStr.replace('今天', formattedToday);
    }
    // 将"YYYY年MM月DD日 HH:MM"格式转化为"YYYY-MM-DD HH:MM"格式，方便 Date 对象解析
    return dateStr.replace(/年|月/g, '-').replace('日', '');
  },

  getIconForCategory(category) {
    const icons = {
      '衣饰': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/yiblue.png',
      '住房': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/zublue.png',
      '餐饮': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/shiblue.png',
      '交通': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/xingblue.png',
      '衣物': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/yiblue.png',
      '工资': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/xinziora.png',
      '投资收益': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/touziora.png',
      '奖金': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/jiangjinora.png',
      '借入': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/jieruora.png',
      '其他':'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/qitahui.png'
    };
    return icons[category] || ''; // 默认返回空字符串
  },

  setCurrentMonth() {
    const date = new Date();
    const month = `${date.getFullYear()}年${date.getMonth() + 1}月`;
    this.setData({ month });
  }
});
