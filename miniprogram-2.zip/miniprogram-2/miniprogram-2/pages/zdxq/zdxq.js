// 引入 wx-charts 和本地数据文件
const wxCharts = require('../../utils/wxcharts');
const financialData = require('../../financialData2');
Page({
  data: {
    month: '',
    expenseCount: 0,
    totalExpense: 0.00,
    incomeCount: 0,
    totalIncome: 0.00,
    balance: 0.00,
    categories: [],
    pieSeries: [],
  },

  onLoad: function () {
    this.loadData();
    
    this.loadChartData();
  },

  loadData: function () {
    const zhichu = wx.getStorageSync('bills') || []; // 获取支出数据
    const shouru = wx.getStorageSync('shouru') || []; // 获取收入数据

    const today = new Date();
    const month = `${today.getFullYear()}年${today.getMonth() + 1}月`;
    this.setData({ month });

    // 计算支出和收入
    const totalExpense = zhichu.reduce((sum, item) => sum + Math.abs(Number(item.amount)), 0);
    const totalIncome = shouru.reduce((sum, item) => sum + Number(item.amount), 0);

    this.setData({
      expenseCount: zhichu.length,
      totalExpense: totalExpense.toFixed(2),
      incomeCount: shouru.length,
      totalIncome: totalIncome.toFixed(2),
      balance: (totalIncome - totalExpense).toFixed(2),
    });
  },

  loadChartData: function () {
    const zhichu = wx.getStorageSync('bills') || []; // 获取支出数据
    const categoryCounts = {};
    const categoryIcons = {
      '住房': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/zublue.png',
      '餐饮': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/shiblue.png',
      '交通': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/xingblue.png',
      '衣物': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/yiblue.png',
      '其他': 'https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/qitahui.png'
      // 在这里添加其他分类图标
    };

    let totalExpense = 0;

    zhichu.forEach(item => {
      const category = item.category;
      const amount = Math.abs(Number(item.amount));
      totalExpense += amount;
      categoryCounts[category] = (categoryCounts[category] || 0) + amount;
    });

    // 生成分类数据列表并计算比例
    const categories = Object.keys(categoryCounts).map(category => ({
      name: category,
      icon: categoryIcons[category] || 'https://example.com/icons/default.png',
      amount: categoryCounts[category].toFixed(2),
      percentage: ((categoryCounts[category] / totalExpense) * 100).toFixed(2) // 计算比例
    }));

    // 生成饼图数据
    const pieSeries = categories.map(cat => ({
      name: cat.name,
      data: parseFloat(cat.amount),
    }));

    this.setData({
      pieSeries,
      categories
    });

    this.renderPieChart();
  },

  renderPieChart: function () {
    new wxCharts({
      canvasId: 'pieChart',
      type: 'pie',
      series: this.data.pieSeries,
      width: 320,
      height: 200
    });
  },

  switchTab(event) {
    wx.navigateTo({
      url: '/pages/srxq/srxq'
    });
  }
});
