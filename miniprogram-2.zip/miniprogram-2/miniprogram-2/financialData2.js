module.exports = {
  expenseCount: 15,
  totalExpense: 378.17,
  incomeCount: 3,
  totalIncome: 1000.00,
  monthTotal: 30.00,
  categories: [
    {
      icon: "../../assets/icons/clothing.png",
      name: "工资",
      percentage: 80,
      amount: 3000.00
    },
    {
      icon: "../../assets/icons/housing.png",
      name: "奖金",
      percentage: 10,
      amount: 500.00
    },
    {
      icon: "../../assets/icons/food.png",
      name: "投资",
      percentage: 10,
      amount: 500.00
    }
  ]
};
