module.exports = {
  expenseCount: 15,
  totalExpense: 378.17,
  incomeCount: 3,
  totalIncome: 1000.00,
  monthTotal: 30.00,
  categories: [
    {
      icon: "https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/yiblue.png",
      name: "衣饰",
      percentage: 12.93,
      amount: 200.00
    },
    {
      icon: "https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/zublue.png",
      name: "住房",
      percentage: 46.02,
      amount: 712.00
    },
    {
      icon: "https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/shiblue.png",
      name: "餐饮",
      percentage: 32.32,
      amount: 500.00
    },
    {
      icon: "https://mp-34a5d4ee-1705-4d90-aebc-3458b73c8f4f.cdn.bspapp.com/jizhang/shouye/xingblue.png",
      name: "交通",
      percentage: 8.72,
      amount: 135.00
    }
  ]
};
