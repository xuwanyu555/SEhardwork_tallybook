module.exports = {
  barCategories: ['8/1', '8/2', '8/3', '8/4', '8/5'], // 柱状图的 X 轴分类
  barSeries: [30, 20, 20, 40, 30], // 柱状图的数据

  pieSeries: [ // 饼图的数据
    { name: '衣饰', data: 500 },
    { name: '住房', data: 600 },
    { name: '餐饮', data: 500 },
    { name: '交通', data: 135 },
    { name: '娱乐', data: 100 }
  ]
};